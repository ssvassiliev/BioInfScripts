#!/bin/bash

INSTALL_DIR=$HOME
ml bowtie2/2.4.4 samtools/1.12 python/2.7.18 mummer/4.0.0beta2
export PATH=$PATH:$INSTALL_DIR/METAASSEMBLER_INSTALL/metassembler-code/bin
