#!/bin/bash

PATCH_DIR=`pwd`
git clone https://git.code.sf.net/p/metassembler/code metassembler-code
ml bowtie2/2.4.4 samtools/1.12 python/2.7.18 mummer/4.0.0beta2
cd metassembler-code/src
patch -p0 reportCE.cpp $PATCH_DIR/reportCE.patch 
patch -p0 Ncoords.cpp $PATCH_DIR/Ncoords.patch
patch -p0 mateAn.cpp $PATCH_DIR/mateAn.patch 
cd ..
make
